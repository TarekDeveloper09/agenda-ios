# PROJECT_STATE — Agenda personal inteligente para iPhone

- **Última actualización:** 26/10/2026, al cerrar la Fase 2 (base de la aplicación).
- **Documentos de referencia:** `docs/FASE_1_ARQUITECTURA.md` (arquitectura y riesgos), `docs/FASE_2_BASE.md` (esta fase).
- **Estado de verificación:** el código de la Fase 2 **NO ha sido compilado ni probado en ningún dispositivo**. Se escribió sin acceso a Swift ni a Xcode. Hasta que la CI compile y el iPhone lo ejecute, nada de lo listado como "implementado" está confirmado.

## 1. Arquitectura vigente (sin cambios respecto a la Fase 1)

- Nativa: Swift + SwiftUI. Sin web, PWA ni frameworks multiplataforma.
- Mínimo **iOS 18.0**.
- `AgendaCore` (Swift Package de lógica pura, con tests) + app SwiftUI + (futura) extensión de controles.
- Proyecto generado con **XcodeGen** desde `project.yml` (el `.xcodeproj` no se versiona).
- Compilación en **GitHub Actions** (runner macOS). Instalación en el iPhone con **Sideloadly** y Apple ID gratuito.
- Persistencia prevista: SwiftData. Notificaciones: locales. Voz: `SFSpeechRecognizer` tras un protocolo propio. Interpretación de frases: analizador propio determinista.

**Ajustes de implementación decididos en la Fase 2 (no alteran la arquitectura):**
- Barra inferior **propia** (no `TabView` estándar): "Añadir" no es una pestaña, abre una hoja, y debe destacar visualmente. Un `TabView` nativo no permite destacar un solo elemento.
- Runner de CI: `macos-26` (según los anuncios de GitHub, Xcode 26.x por defecto; no verificado en una ejecución real).
- Modo de lenguaje Swift 5 (`SWIFT_VERSION = 5.0`) para reducir fricción de concurrencia al escribir código sin poder compilarlo.
- Colores: acento en `Assets.xcassets/AccentColor` con variante clara y oscura; resto, colores semánticos del sistema.

## 2. Archivos existentes y responsabilidad

| Ruta | Responsabilidad |
|---|---|
| `project.yml` | Definición XcodeGen: target `Agenda`, iOS 18.0, bundle id, Info.plist generado, orientación vertical, acento. |
| `.github/workflows/build-ios.yml` | CI: tests de `AgendaCore`, generar proyecto, compilar sin firmar, empaquetar `.ipa`, subir `.ipa` y log. |
| `.gitignore` | Excluye `.xcodeproj`, compilaciones, `.ipa` y archivos de sistema. |
| `PROJECT_STATE.md` | Este documento (estado vivo del proyecto). |
| `docs/FASE_1_ARQUITECTURA.md` | Arquitectura aprobada (referencia, no se edita). |
| `docs/FASE_2_BASE.md` | Descripción, pruebas y criterios de la Fase 2. |
| `Packages/AgendaCore/Package.swift` | Definición del paquete de lógica pura (iOS 18). |
| `Packages/AgendaCore/Sources/AgendaCore/AgendaCore.swift` | **Esqueleto**: solo `moduleName`. Sin lógica. No enlazado a la app aún. |
| `Packages/AgendaCore/Tests/AgendaCoreTests/AgendaCoreTests.swift` | Test mínimo para que la CI ejecute `swift test`. |
| `App/AgendaApp.swift` | Punto de entrada (`@main`); abre `RootView`. |
| `App/Navigation/AppSection.swift` | Enumera las secciones con pantalla (Agenda, Perfil): título e iconos. |
| `App/Navigation/RootView.swift` | Estado de selección, contenido de la sección activa, barra inferior y hoja "Añadir". |
| `App/Navigation/AppBottomBar.swift` | Barra inferior: Agenda · Añadir · Perfil. |
| `App/Navigation/BottomBarTabButton.swift` | Botón de sección (icono + texto, estado seleccionado, accesibilidad). |
| `App/DesignSystem/Theme.swift` | Constantes de espaciado, radios y tamaños. |
| `App/DesignSystem/Components/AddButton.swift` | Botón central destacado "Añadir". |
| `App/DesignSystem/Components/OptionCard.swift` | Tarjeta de opción reutilizable (con o sin acción). |
| `App/Features/Calendar/AgendaView.swift` | Pantalla de agenda: fecha de hoy + estado vacío. |
| `App/Features/QuickCapture/AddOptionsView.swift` | Hoja con las opciones "Añadir por voz" / "Añadir escribiendo" (no funcionales). |
| `App/Features/Settings/ProfileView.swift` | Pantalla de perfil vacía. |
| `App/Resources/Assets.xcassets/` | Catálogo de recursos; `AccentColor` claro/oscuro. |

## 3. Funcionalidades implementadas (SIN VERIFICAR hasta compilar y probar en el iPhone)

- Inicialización de la app y navegación principal (Agenda / Añadir / Perfil).
- Pantalla de agenda vacía con la fecha de hoy.
- Botón central "Añadir" destacado, que abre una hoja.
- Hoja con las dos opciones (solo visuales, etiquetadas "Próximamente").
- Pantalla de perfil vacía.
- Tema claro/oscuro siguiendo el sistema.
- Estructura de carpetas modular según la Fase 1.
- CI de compilación sin firmar y empaquetado `.ipa`.

## 4. Funcionalidades pendientes

Todas las demás: modelos y recurrencia, persistencia, formulario de creación/edición, vistas día/semana/mes/año, analizador de frases, entrada por texto, voz, notificaciones, control de pantalla de bloqueo/App Intents, ajustes reales, localización (es/ca/en), icono de la app, política de privacidad y publicación.

## 5. Dependencias

- **Código:** ninguna externa. Solo frameworks de Apple (SwiftUI).
- **Herramientas de compilación:** GitHub Actions (`actions/checkout@v4`, `actions/upload-artifact@v4`), XcodeGen (vía Homebrew en la CI).
- **Herramientas en Windows:** Git, VS Code, Sideloadly (+ controladores de Apple/iTunes).

## 6. Versiones mínimas

| Elemento | Versión |
|---|---|
| iOS mínimo de la app | 18.0 |
| Dispositivos | solo iPhone (`TARGETED_DEVICE_FAMILY = 1`) |
| Xcode en CI | el de `macos-26` (anunciado Xcode 26.x; confirmar en el log "Mostrar versiones") |
| Swift (modo de lenguaje de la app) | 5.0 |
| swift-tools-version de `AgendaCore` | 5.9 |
| Requisito de Apple para publicar | Xcode 26 / SDK iOS 26 hoy; SDK iOS 27 desde abril de 2027 |

## 7. Problemas conocidos y riesgos abiertos

1. **El código no se ha compilado.** Puede haber errores de compilación; se corregirán con el log de la CI.
2. **XcodeGen y la CI no se han ejecutado.** Posibles fallos: etiqueta de runner, Info.plist generado, ruta del `.app`.
3. **Bundle id con marcador:** `com.TUNOMBRE.agenda.dev` en `project.yml` debe sustituirse antes de instalar.
4. **No hay icono de app:** se verá el icono por defecto.
5. **Barra inferior propia:** el botón "Añadir" sobresale unos puntos sobre la barra; en tamaños de texto de accesibilidad grandes puede requerir ajuste (📱 por comprobar).
6. **Al cambiar de sección se reconstruye la pantalla** (sin estado que perder todavía; se revisará cuando haya datos).
7. **Textos en español dentro del código** (claves de `LocalizedStringKey`); sin archivo `Localizable` hasta la Fase de localización.
8. **Sin pruebas de interfaz.** La única prueba automática es el test mínimo de `AgendaCore`.
9. Siguen abiertos P1–P10 de la Fase 1 (sobre todo P1–P4: control de pantalla de bloqueo con firma gratuita, señal de lanzamiento, catalán, desbloqueo).
10. Los previews de SwiftUI (`#Preview`) no son ejecutables desde Windows; solo sirven si algún día se abre el proyecto en un Mac.

## 8. Próximo paso exacto

**Paso A (el usuario, sin Claude):** validar la cadena de trabajo con esta base.
1. Crear el repositorio en GitHub y subir esta carpeta; sustituir `TUNOMBRE` en `project.yml`.
2. Ver que el workflow "Build iOS" termina en verde; si falla, pegar el log a Claude.
3. Descargar `Agenda-unsigned.ipa`, instalarlo con Sideloadly y comprobar la lista de `docs/FASE_2_BASE.md`.
4. Anotar el resultado en este archivo (sección 7).

**Paso B (siguiente fase, ya con la base funcionando):** ejecutar el **spike de viabilidad de la Fase 1** (antes llamado "Fase 2"): añadir un `ControlWidget` mínimo en pantalla de bloqueo, el indicador de "lanzada por el control" y una prueba de voz en es-ES y ca-ES, para resolver P1–P4 y decidir si se continúa sin pagar. Hacerlo **antes** de invertir en `AgendaCore`.

**Renumeración propuesta de fases:** 2 = base (esta) · 3 = spike de viabilidad · 4 = AgendaCore · 5 = persistencia, formulario y notificaciones · 6 = vistas de calendario · 7 = analizador de texto · 8 = voz · 9 = control de pantalla de bloqueo y atajos definitivos · 10 = ajustes, localización y pulido · 11 = publicación.
