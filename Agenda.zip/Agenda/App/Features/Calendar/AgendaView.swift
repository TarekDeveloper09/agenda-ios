import SwiftUI

/// Pantalla de agenda. En esta fase solo muestra la fecha de hoy y el estado vacío.
struct AgendaView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Text(Date.now, format: .dateTime.weekday(.wide).day().month(.wide))
                    .font(.headline)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, Theme.Spacing.medium)
                    .padding(.top, Theme.Spacing.small)

                ContentUnavailableView {
                    Label("Tu agenda está vacía", systemImage: "calendar")
                } description: {
                    Text("Pulsa el botón + para añadir tu primer evento, tarea o recordatorio.")
                }
            }
            .navigationTitle("Agenda")
        }
    }
}

#Preview("Claro") {
    AgendaView().preferredColorScheme(.light)
}

#Preview("Oscuro") {
    AgendaView().preferredColorScheme(.dark)
}
