import SwiftUI

/// Pantalla de perfil. En esta fase solo muestra el estado vacío.
struct ProfileView: View {
    var body: some View {
        NavigationStack {
            ContentUnavailableView {
                Label("Perfil", systemImage: "person.crop.circle")
            } description: {
                Text("Aquí aparecerán tu perfil y los ajustes de la aplicación.")
            }
            .navigationTitle("Perfil")
        }
    }
}

#Preview("Claro") {
    ProfileView().preferredColorScheme(.light)
}

#Preview("Oscuro") {
    ProfileView().preferredColorScheme(.dark)
}
