import SwiftUI

/// Hoja inicial de "Añadir". Muestra las dos vías de creación.
/// En esta fase ninguna está implementada: las tarjetas no tienen acción.
struct AddOptionsView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Theme.Spacing.medium) {
                    OptionCard(
                        title: "Añadir por voz",
                        subtitle: "Dicta el evento con tu voz",
                        systemImage: "mic.fill"
                    )
                    OptionCard(
                        title: "Añadir escribiendo",
                        subtitle: "Escribe el evento con el teclado",
                        systemImage: "keyboard"
                    )
                }
                .padding(Theme.Spacing.medium)
            }
            .navigationTitle("Añadir")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cerrar") { dismiss() }
                }
            }
        }
    }
}

#Preview("Claro") {
    AddOptionsView().preferredColorScheme(.light)
}

#Preview("Oscuro") {
    AddOptionsView().preferredColorScheme(.dark)
}
