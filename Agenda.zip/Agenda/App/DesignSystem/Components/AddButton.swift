import SwiftUI

/// Botón central "Añadir": circular, con el color de acento y elevado sobre la barra.
struct AddButton: View {
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: "plus")
                .font(.title2.weight(.bold))
                // Color de fondo del sistema: blanco en claro, negro en oscuro.
                // Da buen contraste sobre el acento en ambos temas.
                .foregroundStyle(Color(.systemBackground))
                .frame(width: Theme.Size.addButton, height: Theme.Size.addButton)
                .background(Circle().fill(Color.accentColor))
                .shadow(color: Color.accentColor.opacity(0.35), radius: 8, y: 4)
        }
        .buttonStyle(.plain)
        .offset(y: -Theme.Spacing.medium)
        .padding(.horizontal, Theme.Spacing.medium)
        .accessibilityLabel("Añadir")
        .accessibilityHint("Abre las opciones para añadir un elemento a la agenda")
    }
}
