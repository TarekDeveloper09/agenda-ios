import SwiftUI

/// Constantes de diseño compartidas. Los colores salen del color de acento
/// (Assets.xcassets/AccentColor, con variantes clara y oscura) y de los
/// colores semánticos del sistema, para que el tema claro/oscuro sea automático.
enum Theme {
    enum Spacing {
        static let small: CGFloat = 8
        static let medium: CGFloat = 16
        static let large: CGFloat = 24
    }

    enum Radius {
        static let card: CGFloat = 16
        static let icon: CGFloat = 12
    }

    enum Size {
        static let addButton: CGFloat = 56
        static let optionIcon: CGFloat = 44
        static let minTouchTarget: CGFloat = 44
    }
}
