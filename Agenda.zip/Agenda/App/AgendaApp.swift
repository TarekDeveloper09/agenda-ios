import SwiftUI

@main
struct AgendaApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
