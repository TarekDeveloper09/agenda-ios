import SwiftUI

/// Vista raíz: muestra la sección activa, la barra inferior y la hoja "Añadir".
struct RootView: View {
    @State private var selection: AppSection = .agenda
    @State private var isAddSheetPresented = false

    var body: some View {
        content
            .safeAreaInset(edge: .bottom, spacing: 0) {
                AppBottomBar(selection: $selection) {
                    isAddSheetPresented = true
                }
            }
            .sheet(isPresented: $isAddSheetPresented) {
                AddOptionsView()
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
    }

    @ViewBuilder
    private var content: some View {
        switch selection {
        case .agenda:
            AgendaView()
        case .profile:
            ProfileView()
        }
    }
}

#Preview("Claro") {
    RootView().preferredColorScheme(.light)
}

#Preview("Oscuro") {
    RootView().preferredColorScheme(.dark)
}
