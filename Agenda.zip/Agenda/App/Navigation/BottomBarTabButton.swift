import SwiftUI

/// Botón de una sección de la barra inferior.
struct BottomBarTabButton: View {
    let section: AppSection
    @Binding var selection: AppSection

    private var isSelected: Bool { selection == section }

    var body: some View {
        Button {
            selection = section
        } label: {
            VStack(spacing: 2) {
                Image(systemName: isSelected ? section.selectedSystemImage : section.systemImage)
                    .font(.title3)
                    .accessibilityHidden(true)
                Text(section.title)
                    .font(.caption2)
            }
            .frame(maxWidth: .infinity, minHeight: Theme.Size.minTouchTarget)
            .foregroundStyle(isSelected ? Color.accentColor : Color.secondary)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
        .sensoryFeedback(.selection, trigger: selection)
    }
}
