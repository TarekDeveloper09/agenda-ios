import SwiftUI

/// Barra inferior propia: Agenda · Añadir (destacado) · Perfil.
struct AppBottomBar: View {
    @Binding var selection: AppSection
    let onAdd: () -> Void

    var body: some View {
        HStack(alignment: .bottom, spacing: 0) {
            BottomBarTabButton(section: .agenda, selection: $selection)
            AddButton(action: onAdd)
            BottomBarTabButton(section: .profile, selection: $selection)
        }
        .padding(.horizontal, Theme.Spacing.large)
        .padding(.top, Theme.Spacing.small)
        .padding(.bottom, Theme.Spacing.small)
        .background(.bar)
        .overlay(alignment: .top) {
            Divider()
        }
    }
}
