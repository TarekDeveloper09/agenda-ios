import SwiftUI

/// Secciones con pantalla propia en la barra inferior.
/// "Añadir" no es una sección: abre una hoja (ver RootView).
enum AppSection: Hashable {
    case agenda
    case profile

    var title: LocalizedStringKey {
        switch self {
        case .agenda: "Agenda"
        case .profile: "Perfil"
        }
    }

    var systemImage: String {
        switch self {
        case .agenda: "calendar"
        case .profile: "person.crop.circle"
        }
    }

    var selectedSystemImage: String {
        switch self {
        case .agenda: "calendar"
        case .profile: "person.crop.circle.fill"
        }
    }
}
