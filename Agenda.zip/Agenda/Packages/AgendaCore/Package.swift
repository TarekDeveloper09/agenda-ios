// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "AgendaCore",
    platforms: [.iOS(.v18)],
    products: [
        .library(name: "AgendaCore", targets: ["AgendaCore"])
    ],
    targets: [
        .target(name: "AgendaCore"),
        .testTarget(name: "AgendaCoreTests", dependencies: ["AgendaCore"])
    ]
)
