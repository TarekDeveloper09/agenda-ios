import XCTest
@testable import AgendaCore

final class AgendaCoreTests: XCTestCase {
    func testModuleNameIsStable() {
        XCTAssertEqual(AgendaCore.moduleName, "AgendaCore")
    }
}
