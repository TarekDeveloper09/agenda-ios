// AgendaCore: lógica pura (modelos, recurrencia, analizador de frases).
// ESQUELETO de la Fase 2: todavía no contiene lógica real.
// La app aún no lo enlaza; se enlazará en la Fase 3.

public enum AgendaCore {
    public static let moduleName = "AgendaCore"
}
