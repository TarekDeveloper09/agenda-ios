# FASE 1 — ARQUITECTURA Y VIABILIDAD
## Agenda personal inteligente para iPhone (nativa, SwiftUI)

- **Fecha de redacción:** 26 de octubre de 2026
- **Estado de la fase:** análisis completado. **No hay código escrito. Ninguna funcionalidad está implementada ni verificada en dispositivo.**
- **Cómo usar este documento:** una conversación nueva de Claude debe poder continuar el proyecto leyendo solo este archivo y las instrucciones de la fase siguiente. La sección final `PROJECT_STATE` es el resumen operativo.

### Convención de fiabilidad usada en todo el documento

| Marca | Significado |
|---|---|
| ✅ **Verificado** | Comprobado con búsqueda web en esta fase (fuente indicada). Ojo: muchas fuentes son blogs/foros, no la documentación oficial de Apple. |
| ⚠️ **No verificado** | Procede de conocimiento previo del modelo o de fuentes poco fiables. Debe confirmarse antes de depender de ello. |
| 📱 **Requiere prueba en dispositivo** | Solo se sabrá si funciona probándolo en el iPhone real. |
| 🖥️ **Requiere macOS** | Necesita Xcode, que solo corre en macOS (aquí se resuelve con un Mac en la nube, no con un Mac propio). |

---

## 1. OBJETIVO DEL PROYECTO

Aplicación nativa de iOS: agenda personal con eventos, tareas, recordatorios y actividades recurrentes.

**Función diferencial:** crear elementos hablando de forma natural, idealmente desde un control de la pantalla de bloqueo.

Ejemplo de referencia: el usuario pulsa el control y dice *«Mañana tengo examen de Projecte Intermodular a las siete y veinticinco de la tarde»*. La app interpreta la frase, abre un formulario con título, fecha y hora rellenados, y el usuario confirma o corrige antes de guardar.

**Restricciones del proyecto**

- Desarrollo desde un portátil Windows; dispositivo de pruebas: iPhone 13 Pro; sin Mac propio.
- Presupuesto inicial: 0 €, sin costes recurrentes.
- Desarrollador principiante, asistido por Claude (Claude escribe el código; el usuario lo ejecuta, prueba y devuelve resultados).
- Nativa. Sin web, PWA ni web empaquetada.
- Uso personal primero; publicación en App Store si funciona bien.
- Datos solo locales. Notificaciones solo locales.

**Funcionalidades previstas (referencia):** vistas día/semana/mes/año; eventos, tareas, recordatorios; recurrencia; creación por texto y por voz; interpretación de fechas/horas; formulario autorrellenado; notificaciones locales; acceso desde pantalla de bloqueo; perfil y ajustes; almacenamiento local; interfaz moderna y minimalista.

---

## 2. CONCLUSIÓN DE VIABILIDAD (resumen ejecutivo)

1. **Es técnicamente viable** hacer la app nativa desde Windows, **pero no con Xcode local**. Xcode solo existe para macOS y no se puede virtualizar legalmente en un PC (ver §9).
2. **La vía gratuita recomendada** es: escribir el código en Windows → compilar en un **Mac alquilado por minutos y gratis** dentro de **GitHub Actions** (runners macOS con Xcode real) → instalar el resultado en el iPhone con **Sideloadly** (firmado con un Apple ID gratuito).
3. **Esta vía tiene dos restricciones duras que cambian la experiencia**: (a) no hay simulador ni vista previa de SwiftUI en Windows, así que cada prueba exige compilar en la nube e instalar en el iPhone; (b) con Apple ID gratuito las apps instaladas caducan a los 7 días y hay límites de capacidades (ver §9).
4. **Publicar en la App Store NO es gratis.** Exige el Apple Developer Program: **99 USD/año** (✅ ver registro de verificación). No existe ruta gratuita a la App Store. Esto contradice el presupuesto de 0 € **solo en la fase de publicación**: desarrollo y uso personal pueden hacerse a coste cero; el pago se pospone hasta decidir publicar.
5. **El riesgo técnico principal** no es la agenda, sino la **función estrella**: abrir la app desde un control de pantalla de bloqueo y capturar voz. Es posible en iOS 18 o superior mediante `ControlWidget` + App Intents, pero hay restricciones de ejecución (la app tiene que pasar a primer plano para usar el micrófono) y **la combinación con firma gratuita/sideloading no está verificada**. Por eso la Fase 2 será un **experimento corto (spike)** con una puerta de decisión.
6. **La interpretación de frases se hará con un analizador propio y determinista**, no con IA del sistema, porque la IA del sistema de Apple no está disponible en el iPhone 13 Pro (⚠️ ver §4.6).

---

## 3. ARQUITECTURA RECOMENDADA

### 3.1 Visión general

```
┌──────────────────────── WINDOWS (portátil) ────────────────────────┐
│ VS Code + Git + Swift (solo para tests de lógica pura)             │
│ Claude escribe/edita archivos .swift, project.yml, workflow .yml   │
└───────────────┬────────────────────────────────────────────────────┘
                │ git push
                ▼
┌─────────────── GITHUB ACTIONS (runner macOS, Xcode real) ──────────┐
│ 1. XcodeGen genera el .xcodeproj desde project.yml (texto)         │
│ 2. swift test  → pruebas de la lógica (AgendaCore)                 │
│ 3. xcodebuild → .app/.ipa SIN FIRMAR (o firmado si hay cuenta paga)│
│ 4. Publica el .ipa como artefacto descargable + logs de errores    │
└───────────────┬────────────────────────────────────────────────────┘
                │ descarga del .ipa
                ▼
┌─────────────── WINDOWS ────────────────────────────────────────────┐
│ Sideloadly (USB/Wi-Fi) re-firma con Apple ID gratuito e instala    │
└───────────────┬────────────────────────────────────────────────────┘
                ▼
            iPhone 13 Pro (pruebas reales)
```

**Bucle de trabajo diario:** Claude escribe código → el usuario hace commit/push → Actions compila (errores en el log, que se pegan a Claude) → el usuario descarga el .ipa → lo instala con Sideloadly → prueba en el iPhone → informa a Claude. Cada vuelta tarda minutos, no segundos. Esto condiciona el diseño (ver 3.3).

### 3.2 Arquitectura de la aplicación (capas)

| Capa | Contenido | Depende de iOS | Se puede probar en Windows |
|---|---|---|---|
| **AgendaCore** (Swift Package puro) | Modelos de dominio, motor de recurrencia, analizador de lenguaje natural (es/ca), reglas de recordatorios | No (solo Foundation) | Sí, con `swift test` en Windows o en la CI ⚠️ |
| **App** (SwiftUI) | Pantallas, navegación, formularios, vistas de calendario, ajustes | Sí | No, solo en iPhone |
| **Servicios iOS** | Persistencia (SwiftData), notificaciones (`UserNotifications`), voz (`Speech` + `AVFoundation`) | Sí | No |
| **Extensión de controles** | `ControlWidget` + `AppIntent` para pantalla de bloqueo / Centro de control | Sí | No |

**Principio rector:** todo lo que se pueda expresar como lógica pura (fechas, recurrencias, análisis de frases) va en `AgendaCore` y se prueba con tests automáticos, porque es lo único que se puede validar rápido sin iPhone. La UI se mantiene fina y simple.

### 3.3 Decisiones de diseño derivadas de las limitaciones de Windows

- UI sencilla y repetible (pocos componentes reutilizados), porque no hay vista previa y cada iteración visual cuesta una compilación.
- Cambios pequeños y frecuentes; no reescrituras masivas.
- Los errores de compilación llegan por el log de la CI: Claude los corrige iterativamente.
- Proyecto generado con **XcodeGen** (archivo `project.yml` de texto) para no editar nunca un `.xcodeproj` a mano (imposible en Windows).

---

## 4. TECNOLOGÍAS ELEGIDAS Y JUSTIFICACIÓN

### 4.1 Lenguaje y UI: Swift + SwiftUI

- **Por qué:** es la vía de Apple, da acceso a todas las APIs nativas necesarias (controles de pantalla de bloqueo, App Intents, Speech, notificaciones) sin puentes, y es lo que mejor conoce Claude.
- **Alternativa considerada:** React Native/Expo. ✅ Existe un flujo documentado para compilar sin Mac con EAS Build, y hay paquetes para widgets/controles. **Descartada** porque el control de pantalla de bloqueo, los App Intents y la extensión se escriben igualmente en Swift nativo, añadiendo una capa de JavaScript, más dependencias y más puntos de fallo, sin eliminar la necesidad de compilar en macOS. El requisito del usuario es además «nativa».
- **Alternativa considerada:** Flutter. Descartada por razones análogas (puentes nativos para los controles) y por dependencias que aún no migran por completo a SwiftPM (✅ comentario de comunidad en el hilo de xtool; indicativo, no oficial).
- **Alternativa considerada:** .NET MAUI. Descartada: ✅ requiere igualmente un Mac para compilar iOS.

### 4.2 Versión mínima de iOS: **iOS 18.0**

- ✅ `ControlWidget` y los controles basados en App Intents **no existen antes de iOS 18** (varios tutoriales y la API lo confirman).
- iOS 18 cubre desde iPhone XS/XR en adelante ⚠️ (dato de conocimiento previo; verificar lista oficial de compatibilidad antes de anunciar «compatibilidad»).
- **Trade-off aceptado:** se pierden iPhones que no actualicen a iOS 18. A cambio, se simplifica el código y se garantiza el control de pantalla de bloqueo. Si en el futuro se quisiera iOS 17, habría que condicionar el control con `@available(iOS 18, *)` (⚠️ implica que la extensión de widgets se rediseña).

### 4.3 Persistencia: **SwiftData** (con `Core Data` como plan B)

- Persistencia local nativa, sin servidor, sin coste. SwiftData requiere iOS 17 o superior ⚠️ (compatible con el mínimo iOS 18).
- Los datos de la app se guardarán en el contenedor de la app. Si la extensión de controles necesitara leer datos, haría falta un **App Group** (⚠️ ver riesgos: App Groups con cuenta gratuita no verificado).
- **Diseño intencional:** el control de pantalla de bloqueo **no necesita leer la agenda**; solo abre la app en modo «captura». Así se evita depender de App Groups en la primera versión.
- Plan B: `Core Data` si SwiftData diera problemas de estabilidad en recurrencias o migraciones.

### 4.4 Notificaciones: `UserNotifications` (locales)

- No requiere servidor ni entitlement de push. Solicita permiso al usuario.
- ⚠️ Límite conocido de **64 notificaciones pendientes por app** (conocimiento previo, no verificado en esta fase; confirmar en la documentación de Apple antes de la Fase 4).
- **Consecuencia de diseño:** con eventos recurrentes no se pueden programar todas las apariciones futuras. Estrategia prevista: programar una **ventana móvil** (p. ej. las próximas 2–4 semanas) y reprogramar al abrir la app y en tareas en segundo plano. Para recurrencias simples se puede usar `UNCalendarNotificationTrigger` con `repeats: true`. Se decidirá en la Fase 4.

### 4.5 Reconocimiento de voz (español y catalán)

Hay dos APIs de Apple:

| API | Estado | Idiomas | Notas |
|---|---|---|---|
| `SFSpeechRecognizer` | Existe desde iOS 10 | ✅ Mismos locales que el dictado del teclado (doc. oficial de `supportedLocales()`). Un listado de terceros del conjunto soportado incluye `ca-ES` y `es-ES`. | Límite práctico de ~1 minuto por solicitud (✅ blog); suficiente para frases cortas. Puede enviar audio a los servidores de Apple si no se fuerza reconocimiento en el dispositivo. |
| `SpeechAnalyzer` / `SpeechTranscriber` | Nuevo en iOS 26 | ✅ Fuentes secundarias: al lanzamiento admitía cantonés, chino, inglés, francés, alemán, italiano, japonés, coreano, portugués y español. **El catalán no aparece en esas listas.** | Totalmente en el dispositivo; modelos gestionados por el sistema. `DictationTranscriber` cubre idiomas del dictado clásico. |

**Decisión:** implementar la voz detrás de un protocolo propio (`SpeechService`) con `SFSpeechRecognizer` como primera implementación, forzando reconocimiento en el dispositivo cuando `supportsOnDeviceRecognition` lo permita. `SpeechAnalyzer` queda como optimización futura.

**Dudas abiertas (📱):**
- Si `ca-ES` funciona **en el dispositivo** (sin red) en el iPhone 13 Pro. No se puede afirmar sin probarlo.
- Calidad real del reconocimiento de números hablados («siete y veinticinco») en es y ca; puede devolver «7:25», «19:25» o palabras. El analizador debe aceptar todas las formas.
- Si el reconocimiento por servidor exige declararlo en la política de privacidad (sí, si se usa; ver §8 y §10).

### 4.6 Interpretación de frases: analizador propio determinista

- **Por qué no IA del sistema:** el framework de modelos on-device de Apple depende de Apple Intelligence, que ⚠️ no está disponible en el iPhone 13 Pro (conocimiento previo; verificar). No puede ser requisito.
- **Por qué no solo `NSDataDetector`:** entiende fechas básicas, pero ⚠️ no es fiable con expresiones como «a las siete y veinticinco de la tarde» ni en catalán, y no está garantizado en Linux/Windows para tests. Puede usarse como apoyo, no como base.
- **Diseño:** tuberías de extractores en `AgendaCore`: normalización → detección de **hora** → **fecha** → **recurrencia** → **tipo** (evento/tarea/recordatorio) → **título** (lo que sobra). Siempre se devuelve un `DraftItem` con campo de confianza y el usuario confirma en el formulario.
- Debe cubrir: hoy/mañana/pasado mañana, días de la semana, «el 15 de marzo», «dentro de tres días», «el próximo viernes», «a las 19:25», «y media», «y cuarto», «menos cuarto», «de la mañana/tarde/noche», «todos los lunes», «cada dos semanas». Catalán: «demà», «dilluns», «les set i vint-i-cinc de la tarda», cuartos catalanes («un quart de vuit»).
- Se escribirá con **tests automáticos** (frases de ejemplo → resultado esperado). Es la pieza más testeable del proyecto y se puede validar sin iPhone.

### 4.7 Control de pantalla de bloqueo: `ControlWidget` + App Intents

- ✅ iOS 18 permite controles de terceros en Centro de control, pantalla de bloqueo y botón de Acción (`ControlWidgetButton`/`ControlWidgetToggle` respaldados por App Intents). Es el mecanismo previsto.
- ✅ El intent de abrir la app usa `openAppWhenRun = true`, y (según foros de Apple) **el intent debe estar también compilado en el target principal**, no solo en la extensión, o el control no abre la app / puede fallar.
- ✅ Hay un problema documentado: al lanzar desde el control con la app **cerrada**, un deep link puede no llegar y la app mostrar la pantalla de inicio. **Diseño obligado:** el estado «abrir en modo captura» no debe depender de un deep link; la app debe consultar al arrancar si fue lanzada por el control (ver riesgos).
- **Restricción conceptual (📱):** el control **no graba por sí mismo**. Abre la app (con la autenticación que iOS exija si el iPhone está bloqueado ⚠️) y es la app, en primer plano, la que activa el micrófono. No se debe prometer «hablar sin abrir la app».
- **Alternativas complementarias previstas (⚠️ no verificadas, 📱):**
  - Atajos de Siri mediante App Shortcuts: el usuario dice «Oye Siri, añade a mi agenda» y Siri pide el texto dictado, que llega a la app como texto ya transcrito. Podría ser un camino de captura más robusto.
  - El iPhone 13 Pro **no tiene botón de Acción** (⚠️ es de iPhone 15 Pro en adelante); alternativa: Tocar atrás (Back Tap) de Accesibilidad → un Atajo.

---

## 5. ESTRUCTURA DE ARCHIVOS PREVISTA

(No se genera código todavía. Esta es la estructura objetivo.)

```
Agenda/
├── README.md
├── PROJECT_STATE.md                 ← copia viva del estado (ver §13 y Fase 2)
├── docs/
│   ├── FASE_1_ARQUITECTURA.md       ← este documento
│   └── DECISIONES.md                ← registro de decisiones nuevas
├── project.yml                      ← definición XcodeGen (targets, versión mínima iOS 18)
├── .github/
│   └── workflows/
│       └── build-ios.yml            ← compila en macOS, ejecuta tests, publica .ipa
├── Packages/
│   └── AgendaCore/                  ← lógica pura, probable en Windows/CI
│       ├── Package.swift
│       ├── Sources/AgendaCore/
│       │   ├── Models/              ← AgendaItem, ItemKind, DraftItem
│       │   ├── Recurrence/          ← RecurrenceRule, motor de expansión
│       │   └── Parsing/
│       │       ├── Spanish/         ← extractores de hora/fecha/recurrencia (es)
│       │       ├── Catalan/         ← ídem (ca)
│       │       └── ItemParser.swift ← orquestador
│       └── Tests/AgendaCoreTests/   ← frases → resultados esperados
├── App/
│   ├── AgendaApp.swift
│   ├── Features/
│   │   ├── Calendar/                ← vistas día, semana, mes, año
│   │   ├── ItemEditor/              ← formulario crear/editar
│   │   ├── QuickCapture/            ← pantalla de captura por voz/texto
│   │   ├── Tasks/
│   │   └── Settings/                ← perfil y ajustes
│   ├── Services/
│   │   ├── Persistence/             ← SwiftData
│   │   ├── Notifications/           ← UserNotifications
│   │   └── Speech/                  ← SpeechService + SFSpeechRecognizer
│   ├── DesignSystem/                ← colores, tipografías, componentes
│   └── Resources/                   ← Localizable (es/ca/en), iconos, Info.plist
├── AgendaControls/                  ← extensión de controles
│   ├── AgendaControlsBundle.swift
│   ├── CaptureControl.swift         ← ControlWidget
│   └── (intent compartido también en App/)
└── Shared/
    └── OpenCaptureIntent.swift      ← AppIntent compartido por app y extensión
```

---

## 6. HERRAMIENTAS GRATUITAS NECESARIAS

| Herramienta | Uso | Coste | Fiabilidad de la información |
|---|---|---|---|
| Visual Studio Code | Editar archivos | Gratis | — |
| Git + cuenta de GitHub | Control de versiones y CI | Gratis | ✅ |
| GitHub Actions (runners macOS) | Compilar con Xcode real | Gratis en repos públicos; en privados hay minutos incluidos, y los de macOS consumen 10 veces más (⚠️ fuente secundaria: unos ~200 minutos efectivos al mes; verificar el plan actual) | ✅/⚠️ |
| XcodeGen | Generar `.xcodeproj` desde `project.yml` | Gratis (código abierto) | ⚠️ |
| Sideloadly | Re-firmar e instalar .ipa desde Windows por USB/Wi-Fi | Gratis | ✅ (Windows y macOS; requiere controladores de Apple/iTunes ⚠️ verificar versión exigida) |
| AltStore + AltServer | Alternativa a Sideloadly con refresco automático | Gratis | ✅ (requiere ordenador en la misma red para renovar) |
| Apple ID gratuito | Firma personal para pruebas | Gratis | ✅ |
| Swift para Windows | Ejecutar tests de `AgendaCore` localmente | Gratis | ⚠️ confirmar instalación en la Fase 2 |
| Codemagic (plan gratuito) | Alternativa a Actions | ⚠️ una fuente secundaria cita 500 min macOS/mes; verificar | ⚠️ |
| xtool | Compilar/instalar Swift desde Windows (WSL) sin macOS | Gratis | ✅ existe; ver §7.2 sobre limitaciones |

**Repositorio público vs privado:** si el repositorio es público, la compilación en macOS es gratuita pero el código es visible. Si es privado, hay que vigilar la cuota. Decisión pendiente (ver `PROJECT_STATE`).

---

## 7. PROCEDIMIENTO DE DESARROLLO DESDE WINDOWS

### 7.1 Ruta principal (recomendada): código en Windows + compilación en macOS en la nube

1. Instalar Git y VS Code; crear cuenta de GitHub y repositorio.
2. Claude escribe `project.yml`, el workflow de CI, `AgendaCore` y la app.
3. `git push` dispara el workflow en un runner macOS.
4. El workflow ejecuta XcodeGen, los tests de `AgendaCore` y `xcodebuild`, y sube el `.ipa` como artefacto.
5. Los errores se leen en el log de Actions y se pegan a Claude para corregirlos.
6. Con la app compilada se pasa a la instalación (§8).

**Por qué esta ruta:** usa Xcode real (la cadena de herramientas completa de Apple), incluida la generación de metadatos de App Intents que los controles necesitan (⚠️ ver 7.2), no requiere comprar un Mac ni pagar, y es lo más mantenible.

### 7.2 Ruta secundaria (no recomendada como principal): xtool en WSL

- ✅ xtool es un proyecto de código abierto que compila un paquete SwiftPM a una app iOS, la firma e instala desde Linux/Windows (WSL).
- ✅ Limitaciones citadas por sus propios usuarios y su documentación: necesita un `Xcode.xip` descargado para extraer el SDK de iOS; en su día no soportaba extensiones ni la mayoría de entitlements (la documentación actual indica que ya se pueden añadir extensiones como widgets declarándolas en `xtool.yml`, ⚠️ no verificado en la práctica).
- ⚠️ **Riesgo específico para este proyecto:** los controles de pantalla de bloqueo dependen de metadatos de App Intents que Xcode genera en compilación; no se ha verificado que xtool los genere. Sin ellos, el control podría no aparecer o no funcionar.
- ⚠️ **Licencia:** usar el SDK de Xcode fuera de hardware Apple podría chocar con el acuerdo de licencia de Xcode. No se emite aquí valoración legal; es un riesgo a tener en cuenta.
- **Uso previsto:** solo como plan B si el flujo de la CI resultara inviable.

### 7.3 Rutas descartadas

- **Máquina virtual de macOS en el PC:** ✅ la licencia de Apple solo permite macOS en hardware Apple.
- **Mac en la nube alquilado (p. ej. MacinCloud):** ✅ existe desde unos 26 USD/mes según una fuente secundaria. **Descartado como opción base** por ser coste recurrente; queda como último recurso si fallan las otras rutas (acceso remoto a un Xcode real con simulador).

---

## 8. PROCEDIMIENTO PREVISTO PARA PROBAR EN UN iPHONE

### 8.1 Pruebas personales sin pagar (Apple ID gratuito + Sideloadly)

1. En Windows: instalar iTunes/controladores de Apple y Sideloadly.
2. Descargar el `.ipa` sin firmar generado por la CI.
3. Conectar el iPhone 13 Pro por USB, activar el **Modo desarrollador** en iOS y confiar en el ordenador ⚠️ (los pasos exactos se verificarán en la Fase 2).
4. Sideloadly re-firma el .ipa con tu Apple ID gratuito y lo instala.
5. En el iPhone: Ajustes → General → VPN y gestión de dispositivos → confiar en el perfil.

**Limitaciones de la firma gratuita (✅ fuentes de foros/blogs, algunas antiguas; verificar valores actuales):**
- Los perfiles de aprovisionamiento caducan a los **7 días**: hay que re-firmar e instalar cada semana (AltStore puede automatizarlo mientras AltServer esté activo en tu PC).
- Límite de **3 apps activas** por Apple ID con sideloading y un tope de **10 App IDs nuevos por 7 días**. Las extensiones (como el control) consumen App IDs: app + extensión ≈ 2.
- Las capacidades (entitlements) están restringidas; ⚠️ no verificado si los **App Groups** funcionan con el flujo Sideloadly/AltStore en este proyecto.
- Sin TestFlight (✅ requiere el programa de pago).

### 8.2 Pruebas con cuenta de pago (si se decide pagar)

Con el Apple Developer Program (99 USD/año): perfiles de 1 año, TestFlight, capacidades completas y publicación (§9). Se evalúa en una puerta de decisión (ver Fase 2 y §11).

### 8.3 Matriz de pruebas imprescindible en iPhone real

Control de pantalla de bloqueo, micrófono + reconocimiento, notificaciones con la app cerrada, comportamiento con el iPhone bloqueado/desbloqueado, ahorro de batería, permisos denegados.

---

## 9. LIMITACIONES TÉCNICAS

### 9.1 Trabajar desde Windows

- **Sin simulador y sin vista previa de SwiftUI.** Toda prueba visual es en el iPhone real.
- **Compilaciones lentas** (minutos) y dependientes de la nube.
- **No se puede depurar con Xcode** (sin breakpoints); solo logs, `print` y registros de la app.
- **No se puede subir a App Store Connect con Transporter/Xcode locales**: la subida se hará desde la CI con una clave de API de App Store Connect (⚠️ proceso a verificar en la fase de publicación).
- **Firma:** sin cuenta de pago, la firma es la limitada del Apple ID gratuito.

### 9.2 Plataforma

- ✅ **Requisitos de SDK de Apple:** desde el 28 de abril de 2026, las apps subidas a App Store Connect deben compilarse con **Xcode 26 o posterior** y el SDK de iOS 26 (fuente: página oficial de Apple recogida en una fuente secundaria y en el listado «SDK minimum requirements»).
- ✅ **Xcode 27 (Swift 6.4) salió el 14 de septiembre de 2026** junto con iOS 27. **A partir de abril de 2027** las subidas exigirán el SDK de iOS 27 y objetivo iOS 15 o superior. **Consecuencia:** para publicar después de abril de 2027, el runner de CI debe tener Xcode 27 (⚠️ no verificado que GitHub Actions lo ofrezca).
- ✅ Xcode 27 requiere macOS Tahoe 26.6 o superior y Mac con Apple silicon (relevante para los runners; no lo gestionas tú).
- ⚠️ No verificado si el iPhone 13 Pro es compatible con iOS 27; no condiciona el proyecto (mínimo iOS 18).

### 9.3 Funciones: clasificación

| Función | ¿Técnicamente posible? | ¿Necesita macOS? | ¿Requiere prueba en dispositivo? |
|---|---|---|---|
| Persistencia local SwiftData | Sí ⚠️ | 🖥️ para compilar | Sí 📱 |
| Vistas día/semana/mes/año | Sí | 🖥️ | Sí 📱 (sin simulador) |
| Eventos/tareas/recordatorios | Sí | 🖥️ | Sí 📱 |
| Recurrencia (motor propio) | Sí | No para la lógica pura | Parcial |
| Analizador de frases es/ca | Sí | No para la lógica pura | Calidad con voz real 📱 |
| Notificaciones locales | Sí ✅ | 🖥️ | 📱 |
| Voz en español | Sí ✅ (API existente) | 🖥️ | 📱 |
| Voz en catalán | Probable ⚠️ (ca-ES en la lista de terceros) | 🖥️ | 📱 crítico |
| Control en pantalla de bloqueo | Sí en iOS 18+ ✅ | 🖥️ (metadatos App Intents) | 📱 crítico |
| «Hablar sin abrir la app» desde el control | **No garantizado; no prometer** | — | 📱 |
| Sideload con firma gratuita incluyendo extensión | ⚠️ sin verificar | No | 📱 crítico |
| Publicación en App Store | Sí, de pago ✅ | Subida desde CI | — |

---

## 10. RIESGOS Y ALTERNATIVAS

| # | Riesgo | Prob./Impacto | Mitigación / alternativa |
|---|---|---|---|
| R1 | La extensión de controles no funciona instalada con firma gratuita (entitlements, App Groups, límite de App IDs). | Media / **Alto** | Spike en Fase 2. Si falla: puerta de decisión → pagar los 99 USD/año o usar captura por Siri/Atajo y botón dentro de la app. |
| R2 | El control abre la app pero no inicia la captura (deep link perdido con app cerrada). | Alta (✅ documentado) / Medio | No depender de deep link: la app lee un indicador de «lanzada por control» al arrancar. Probar app cerrada, en segundo plano y bloqueada. |
| R3 | `ca-ES` sin red no disponible o con mala calidad. | Media / Medio | Entrada de texto siempre disponible; permitir reconocimiento por servidor con aviso de privacidad; revisar `SpeechAnalyzer`/`DictationTranscriber` según locales. |
| R4 | Mala interpretación de frases. | Alta / Medio | Formulario de confirmación siempre; tests con corpus de frases; campo de confianza visible. |
| R5 | Límite de 64 notificaciones y recurrencias. | Alta (⚠️ verificar) / Medio | Ventana móvil + reprogramación. |
| R6 | Cuota de GitHub Actions en repo privado. | Media / Bajo | Repo público (sin secretos), pruebas locales de lógica, compilar solo cuando haga falta. |
| R7 | Caducidad semanal de la firma gratuita. | Cierta / Bajo-medio | AltStore o re-instalación semanal; considerar pago si se usa a diario. |
| R8 | Cambios de requisitos de Apple (SDK de abril de 2027). | Cierta / Medio | Mantener CI actualizada; planificar migración a Xcode 27 antes de publicar. |
| R9 | Rechazo en App Review o falta de política de privacidad. | Media / Medio | Política de privacidad alojada gratis (p. ej. GitHub Pages), declaración de datos, reconocimiento de voz explicado. |
| R10 | Desfase entre código escrito «a ciegas» y errores de compilación. | Alta / Bajo | Cambios pequeños; tests; logs de CI. |
| R11 | Conflicto de licencia con xtool/SDK fuera de Apple. | ⚠️ Desconocida | Usarlo solo como plan B y asumiendo el riesgo; no es la ruta base. |

**Alternativas globales si la ruta principal falla:**
1. Pagar el Apple Developer Program (99 USD/año) para firma de 1 año, TestFlight y publicación.
2. Alquilar un Mac en la nube por meses concretos (coste recurrente).
3. Reducir la función estrella: botón dentro de la app + Atajo de Siri para captura, sin control en pantalla de bloqueo.

**Publicación en App Store: condiciones**
- ✅ Apple Developer Program: 99 USD/año (inscripción individual: aparece tu nombre legal como vendedor; verificación típica de 24–48 h según una fuente secundaria; la de organización requiere D-U-N-S y tarda más).
- ✅ Compilación con la versión de Xcode exigida en ese momento (§9.2).
- ✅ Ficha en App Store Connect: descripción, capturas de pantalla, información de privacidad, clasificación de edad, política de privacidad.
- ⚠️ Existen exenciones de cuota para organizaciones sin ánimo de lucro, educativas o gubernamentales; no se ha verificado si aplican a un caso personal. No contar con ellas.
- ⚠️ No se ha verificado la distribución alternativa en la UE (mercados alternativos / web); no se considera en este proyecto.
- ✅ Una cuenta de pago caducada retira las apps de nuevas descargas.

---

## 11. PLAN DE DESARROLLO DE LAS SIGUIENTES FASES

Cada fase es independiente, termina con un entregable verificable y **no se da por completada hasta probarla en el iPhone**.

**Fase 2 — Entorno y spike de viabilidad (puerta de decisión).**
Objetivo: demostrar el bucle completo con el mínimo código. Entregables: repositorio en GitHub, `project.yml`, workflow de CI que compila una app mínima («Hola») con una extensión `ControlWidget`; instalación en el iPhone con Sideloadly; comprobar que (1) la app instala y abre, (2) el control aparece en pantalla de bloqueo, (3) pulsarlo abre la app, (4) la app puede pedir permiso de micrófono y de reconocimiento y transcribir una frase en **es-ES** y **ca-ES** (en el dispositivo y con red), (5) la app lee el indicador «lanzada por control». **Puerta de decisión:** si falla la firma gratuita con la extensión → decidir entre pagar 99 USD/año, usar solo Atajo/Siri, o intentar xtool.

**Fase 3 — AgendaCore: modelos y recurrencia.**
Modelos (`AgendaItem`, tipos, `RecurrenceRule`), motor de expansión, tests. Sin UI.

**Fase 4 — Persistencia, formulario y notificaciones.**
SwiftData, lista simple, formulario de creación/edición, notificaciones locales con ventana móvil.

**Fase 5 — Vistas de calendario.**
Día, semana, mes y año; navegación; interfaz minimalista y sistema de diseño.

**Fase 6 — Analizador de texto (español, luego catalán).**
Extractores de hora/fecha/recurrencia/tipo/título; corpus de pruebas; pantalla de captura por texto que abre el formulario rellenado.

**Fase 7 — Captura por voz.**
`SpeechService`, permisos, flujo voz → texto → analizador → formulario; manejo de errores; pruebas es/ca en el dispositivo.

**Fase 8 — Control de pantalla de bloqueo y atajos.**
`ControlWidget` definitivo, intent compartido, modo captura al lanzar; App Shortcuts/Siri; pruebas con app cerrada, en segundo plano y con iPhone bloqueado.

**Fase 9 — Perfil, ajustes, localización y pulido.**
Idioma (es/ca/en), preferencias, accesibilidad (Dynamic Type, VoiceOver), iconos, pruebas de uso diario.

**Fase 10 — Publicación (opcional, de pago).**
Decisión de pagar 99 USD/año, política de privacidad, ficha, capturas, subida desde CI, TestFlight, revisión, publicación; revisar requisito de SDK vigente en ese momento.

---

## 12. CRITERIOS PARA CONSIDERAR TERMINADO EL PROYECTO

**Versión personal (obligatoria):**
1. Crear eventos, tareas y recordatorios por texto y por voz; el formulario aparece relleno y editable antes de guardar.
2. La frase de referencia del §1 produce el título «examen de Projecte Intermodular», fecha de mañana y hora 19:25 al menos en el 90 % de un corpus de pruebas definido en la Fase 6 (umbral provisional).
3. Vistas de día, semana, mes y año funcionan con datos reales.
4. Eventos recurrentes se crean, se muestran y notifican correctamente (casos acordados en la Fase 3).
5. Las notificaciones llegan con la app cerrada, incluyendo recurrencias.
6. El control de pantalla de bloqueo abre la app en modo captura con la app cerrada, en segundo plano y con el iPhone bloqueado (comportamiento exacto documentado tras las pruebas).
7. Funciona sin red para el flujo principal, o el requisito de red está documentado y comunicado al usuario.
8. Datos persisten tras reiniciar el iPhone y actualizar la app.
9. Sin cierres inesperados durante una semana de uso real.

**Versión publicable (si se decide):** además, política de privacidad, declaración de datos de App Store Connect, pruebas en al menos otro modelo de iPhone, cumplimiento del SDK exigido, aprobación de App Review.

---

## REGISTRO DE VERIFICACIÓN (búsquedas realizadas el 26/10/2026)

| Afirmación | Estado | Origen |
|---|---|---|
| Apple Developer Program cuesta 99 USD/año; imprescindible para App Store; TestFlight de pago | ✅ | Varias fuentes secundarias (no se consultó la página de Apple directamente) |
| Cuenta individual muestra nombre legal; verificación de 24–48 h | ⚠️ | Una fuente secundaria |
| Xcode 26/iOS 26 SDK obligatorio desde 28/04/2026 | ✅ | Listado de requisitos de Apple (vía fuente secundaria) |
| Xcode 27 y iOS 27 lanzados el 14/09/2026; requisito de SDK 27 desde abril de 2027 | ✅ | Prensa y blogs de desarrolladores |
| Controles de pantalla de bloqueo requieren iOS 18; `openAppWhenRun`; intent en el target principal | ✅ | Foros de Apple y tutoriales |
| Fallo de deep link con app cerrada al lanzar desde el control | ✅ | Artículo de comunidad (un caso) |
| `SFSpeechRecognizer.supportedLocales` = locales del dictado del teclado | ✅ | Documentación de Apple |
| `ca-ES` en la lista de locales de `SFSpeechRecognizer` | ⚠️ | Listado de terceros (plugin), no Apple |
| `SpeechAnalyzer` (iOS 26), sin catalán en la lista de lanzamiento | ✅/⚠️ | Blogs |
| Catalán funciona **en el dispositivo** | ⚠️ **desconocido** | Pendiente de prueba 📱 |
| Firma gratuita: 7 días; 3 apps; 10 App IDs/semana | ✅/⚠️ | Foros y blogs, algunos antiguos |
| App Groups / entitlements con Sideloadly/AltStore | ⚠️ **desconocido** | Pendiente de prueba 📱 |
| xtool compila/instala desde Windows (WSL); límites de extensiones | ✅/⚠️ | README y foros |
| GitHub Actions macOS ×10 en minutos; Codemagic 500 min | ⚠️ | Fuentes secundarias |
| Límite de 64 notificaciones; SwiftData iOS 17+; Foundation Models requiere Apple Intelligence; Back Tap | ⚠️ | Conocimiento previo del modelo |
| Mac en la nube desde ~26 USD/mes | ✅ | Fuente secundaria |

---

## PROJECT_STATE

### Estado
- **Fase actual:** Fase 1 (arquitectura) **terminada como análisis**. No existe código. **Ninguna funcionalidad está completada.**
- **Fecha del estado:** 26/10/2026.

### Decisiones técnicas definitivas (salvo que la puerta de decisión de la Fase 2 las cambie)
1. **Nativa:** Swift + SwiftUI. Sin web, PWA ni frameworks multiplataforma.
2. **Mínimo iOS 18.0** (por `ControlWidget`).
3. **Estructura:** `AgendaCore` (Swift Package con lógica pura y tests) + app SwiftUI + extensión de controles. Proyecto generado con **XcodeGen** desde `project.yml`.
4. **Compilación:** **GitHub Actions con runner macOS** (Xcode real). Sin VM de macOS, sin Mac comprado.
5. **Instalación en iPhone:** `.ipa` sin firmar re-firmado con **Sideloadly** (o AltStore) y Apple ID gratuito.
6. **Persistencia:** SwiftData (plan B: Core Data). Los datos no se comparten con la extensión en la v1.
7. **Notificaciones:** locales, ventana móvil de programación.
8. **Voz:** `SpeechService` (protocolo propio) con `SFSpeechRecognizer` primero; `SpeechAnalyzer` como mejora futura.
9. **Interpretación de frases:** analizador **propio y determinista** en `AgendaCore`, con tests; siempre pasa por formulario de confirmación. No depender de IA del sistema.
10. **El control de pantalla de bloqueo solo abre la app en modo captura**; no se promete grabar sin abrir la app.
11. **El pago de 99 USD/año se pospone** hasta la publicación o hasta que la puerta de decisión de la Fase 2 lo exija.
12. **Bundle ID de desarrollo distinto del final** (p. ej. `com.TUNOMBRE.agenda.dev`) para evitar conflictos al pasar a cuenta de pago.

### Dudas pendientes (resolver en Fase 2 salvo indicación)
- **P1** ¿Funciona la extensión `ControlWidget` instalada con Apple ID gratuito vía Sideloadly/AltStore (entitlements, App Groups, límite de App IDs)? 📱 *Crítica.*
- **P2** ¿Cómo llega a la app la señal «lanzada por el control» con la app cerrada? 📱
- **P3** ¿`ca-ES` funciona en el dispositivo (sin red) en el iPhone 13 Pro? ¿Y `es-ES`? ¿Cómo transcribe los números hablados? 📱
- **P4** ¿Qué exige iOS para lanzar la app desde el control con el iPhone bloqueado (desbloqueo)? 📱
- **P5** ¿Repositorio público (compilación gratis, código visible) o privado (cuota limitada)? **Decide el usuario.**
- **P6** Verificar cuota vigente de GitHub Actions macOS y versión de Xcode disponible en los runners (26 y 27).
- **P7** Verificar límite de notificaciones pendientes y pasos exactos del modo desarrollador / instalación con Sideloadly.
- **P8** ¿Compatibilidad del iPhone 13 Pro con iOS 27 y rango real de iPhones con iOS 18? Verificar antes de anunciar compatibilidad.
- **P9** Idioma(s) de la app: ¿solo es y ca, o también en? **Decide el usuario.**
- **P10** Opción Atajos de Siri/Back Tap como camino de captura alternativo. ⚠️ Por validar.

### Siguiente paso exacto
**Iniciar la Fase 2 (entorno y spike de viabilidad)** con el siguiente alcance:
1. El usuario crea cuenta de **GitHub** y un **Apple ID gratuito** (preferiblemente uno dedicado al desarrollo) y decide P5.
2. En una conversación nueva de Claude, adjuntar este archivo y pedir: *«Ejecuta la Fase 2: guíame paso a paso para preparar el entorno y crear el proyecto mínimo con compilación en GitHub Actions, instalación con Sideloadly y un ControlWidget de prueba en pantalla de bloqueo, más una prueba de reconocimiento de voz en es-ES y ca-ES. No añadas funcionalidades de agenda.»*
3. Al terminar la Fase 2, **actualizar este `PROJECT_STATE`** (resultado de P1–P4) y decidir: continuar sin pagar, pagar los 99 USD/año, o reducir la función de pantalla de bloqueo.
