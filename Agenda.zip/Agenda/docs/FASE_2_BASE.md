# FASE 2 — BASE DE LA APLICACIÓN

**Estado:** código escrito, **sin compilar ni probar** (no hubo acceso a Swift/Xcode al escribirlo).

## Objetivo
Estructura inicial funcional: navegación (Agenda · Añadir · Perfil), agenda vacía, botón central destacado con hoja de opciones, perfil vacío, tema claro/oscuro y estructura modular según `FASE_1_ARQUITECTURA.md`.

## Decisiones de esta fase
- **Barra inferior propia** en lugar de `TabView`: "Añadir" no es una pestaña (abre una hoja) y debe destacar. Un `TabView` estándar no permite resaltar un solo elemento. Se mantienen etiquetas, tamaño táctil mínimo de 44 pt y rasgo "seleccionado" para VoiceOver.
- **Hoja de "Añadir"** con `presentationDetents([.medium, .large])` y contenido en `ScrollView`, para que no se corte con texto grande.
- **Opciones no funcionales** mostradas como tarjetas sin acción y con la etiqueta "Próximamente" (no hay botones falsos).
- **Tema:** automático con el sistema. Color de acento con variantes clara/oscura; el icono "+" usa el color de fondo del sistema para mantener contraste en ambos temas.
- **Estados vacíos:** `ContentUnavailableView` (componente nativo, iOS 17+).
- **AgendaCore** existe como esqueleto con un test mínimo; aún no se enlaza a la app.
- **Sin dependencias externas.**

## Cómo compilar
1. Sube la carpeta a un repositorio de GitHub (rama `main`).
2. En `project.yml`, sustituye `TUNOMBRE` por un alias en minúsculas.
3. En GitHub → pestaña *Actions* → "Build iOS". Se ejecuta con cada push, o con *Run workflow*.
4. Cuando termine en verde, descarga el artefacto `Agenda-unsigned-ipa`, descomprímelo y obtén `Agenda-unsigned.ipa`.
5. Instálalo en el iPhone con Sideloadly (Apple ID gratuito) y confía en el perfil en Ajustes → General → VPN y gestión de dispositivos. En iOS 18 y superior, activa antes el Modo desarrollador si el sistema lo pide.
6. Si el workflow falla, descarga el artefacto `xcodebuild-log` (o copia el error del paso que falló) y pásaselo a Claude.

## Qué probar en el iPhone
1. La app abre en la pestaña **Agenda**, con el título "Agenda", la fecha de hoy y el mensaje "Tu agenda está vacía".
2. La barra inferior muestra **Agenda**, un botón circular **+** más grande y elevado, y **Perfil**.
3. Pulsar **Perfil** cambia de pantalla; el icono y el texto de Perfil se resaltan en el color de acento. Volver a **Agenda** funciona.
4. Pulsar **+** abre una hoja con dos tarjetas: "Añadir por voz" y "Añadir escribiendo", ambas con la etiqueta "Próximamente" y sin ninguna acción al tocarlas.
5. La hoja se cierra con **Cerrar** y arrastrando hacia abajo.
6. **Tema:** Ajustes del iPhone → Pantalla y brillo → alterna Claro/Oscuro con la app abierta. Todo debe verse legible, sin texto invisible, y el "+" debe seguir distinguiéndose.
7. **Texto grande:** Ajustes → Accesibilidad → Tamaño del texto → un tamaño grande. Comprueba que la barra y las tarjetas siguen siendo legibles y que la hoja permite hacer scroll.
8. **VoiceOver** (opcional): el botón **+** se anuncia como "Añadir" con su ayuda; la pestaña activa se anuncia como seleccionada.
9. La app no se cierra sola.

## La fase está correctamente completada si
- El workflow "Build iOS" termina en verde, incluyendo `swift test`.
- Se genera `Agenda-unsigned.ipa` y se instala en el iPhone 13 Pro.
- Se cumplen los puntos 1–6 y 9 de la lista anterior.
- Los puntos 7–8 no revelan problemas graves (si los hay, anotarlos en `PROJECT_STATE.md`).

## Fuera de alcance (no implementado)
Datos, formulario, voz, texto, analizador, notificaciones, vistas de calendario, control de pantalla de bloqueo, ajustes reales, localización, icono.
